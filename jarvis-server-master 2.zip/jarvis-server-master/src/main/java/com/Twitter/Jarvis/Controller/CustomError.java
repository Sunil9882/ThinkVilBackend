package com.Twitter.Jarvis.Controller;

public interface CustomError {
    public String getErrorPath();
}
