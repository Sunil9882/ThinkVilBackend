package com.Twitter.Jarvis.Config;

public class JwtConstant {
    public static final String SECRET_KEY="9a4f2c8d3b7a1e6f45c8a0b3f267d8b1d4e6f3c8a9d2b5f8e3a9c8b5f6v8a3d9";
    public static final String JWT_HEADER = "Authorization";
}
